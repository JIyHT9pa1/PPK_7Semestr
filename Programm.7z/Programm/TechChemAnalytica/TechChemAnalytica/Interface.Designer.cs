﻿namespace TechChemAnalytica
{
    partial class Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Interface));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.menuStripControl = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменитьПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.экспортВMSExelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.functionAdminsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьредактироватьМатериалToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.учетныеЗаписиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользовательToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.buttonExport = new System.Windows.Forms.Button();
            this.buttonClearBox1 = new System.Windows.Forms.Button();
            this.buttonСalculate1 = new System.Windows.Forms.Button();
            this.tStep = new System.Windows.Forms.TextBox();
            this.tMax = new System.Windows.Forms.TextBox();
            this.tMin = new System.Windows.Forms.TextBox();
            this.PgStep = new System.Windows.Forms.TextBox();
            this.PgMax = new System.Windows.Forms.TextBox();
            this.PgMin = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxMaterial = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Label_Info = new System.Windows.Forms.Label();
            this.chartAreaOne = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.chartAreaTwo = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.menuStripControl.SuspendLayout();
            this.groupBox.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartAreaOne)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartAreaTwo)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStripControl
            // 
            this.menuStripControl.BackColor = System.Drawing.Color.LightGray;
            this.menuStripControl.Font = new System.Drawing.Font("Arial", 10F);
            this.menuStripControl.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.functionAdminsToolStripMenuItem,
            this.HelpToolStripMenuItem,
            this.пользовательToolStripMenuItem});
            this.menuStripControl.Location = new System.Drawing.Point(0, 0);
            this.menuStripControl.Name = "menuStripControl";
            this.menuStripControl.Size = new System.Drawing.Size(1384, 27);
            this.menuStripControl.TabIndex = 0;
            this.menuStripControl.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сменитьПользователяToolStripMenuItem,
            this.экспортВMSExelToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(54, 23);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // сменитьПользователяToolStripMenuItem
            // 
            this.сменитьПользователяToolStripMenuItem.Name = "сменитьПользователяToolStripMenuItem";
            this.сменитьПользователяToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.сменитьПользователяToolStripMenuItem.Text = "Сменить пользователя";
            this.сменитьПользователяToolStripMenuItem.Click += new System.EventHandler(this.ChangeUserToolStripMenuItem_Click);
            // 
            // экспортВMSExelToolStripMenuItem
            // 
            this.экспортВMSExelToolStripMenuItem.Name = "экспортВMSExelToolStripMenuItem";
            this.экспортВMSExelToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.экспортВMSExelToolStripMenuItem.Text = "Экспорт в MS Excel";
            this.экспортВMSExelToolStripMenuItem.Click += new System.EventHandler(this.Export_ToExelToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.СLoseAppToolStripMenuItem_Click);
            // 
            // functionAdminsToolStripMenuItem
            // 
            this.functionAdminsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьредактироватьМатериалToolStripMenuItem,
            this.учетныеЗаписиToolStripMenuItem});
            this.functionAdminsToolStripMenuItem.Name = "functionAdminsToolStripMenuItem";
            this.functionAdminsToolStripMenuItem.Size = new System.Drawing.Size(256, 23);
            this.functionAdminsToolStripMenuItem.Text = "Функции технического специалиста";
            // 
            // добавитьредактироватьМатериалToolStripMenuItem
            // 
            this.добавитьредактироватьМатериалToolStripMenuItem.Name = "добавитьредактироватьМатериалToolStripMenuItem";
            this.добавитьредактироватьМатериалToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.добавитьредактироватьМатериалToolStripMenuItem.Text = "Добавить/редактировать материал";
            this.добавитьредактироватьМатериалToolStripMenuItem.Click += new System.EventHandler(this.ChangeMaterialToolStripMenuItem_Click);
            // 
            // учетныеЗаписиToolStripMenuItem
            // 
            this.учетныеЗаписиToolStripMenuItem.Name = "учетныеЗаписиToolStripMenuItem";
            this.учетныеЗаписиToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.учетныеЗаписиToolStripMenuItem.Text = "Учетные записи";
            this.учетныеЗаписиToolStripMenuItem.Click += new System.EventHandler(this.ProfilesUserToolStripMenuItem_Click);
            // 
            // HelpToolStripMenuItem
            // 
            this.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem";
            this.HelpToolStripMenuItem.Size = new System.Drawing.Size(74, 23);
            this.HelpToolStripMenuItem.Text = "Справка";
            this.HelpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItem_Click);
            // 
            // пользовательToolStripMenuItem
            // 
            this.пользовательToolStripMenuItem.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.пользовательToolStripMenuItem.Name = "пользовательToolStripMenuItem";
            this.пользовательToolStripMenuItem.Size = new System.Drawing.Size(147, 23);
            this.пользовательToolStripMenuItem.Text = "Пользователь: ";
            this.пользовательToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.buttonExport);
            this.groupBox.Controls.Add(this.buttonClearBox1);
            this.groupBox.Controls.Add(this.buttonСalculate1);
            this.groupBox.Controls.Add(this.tStep);
            this.groupBox.Controls.Add(this.tMax);
            this.groupBox.Controls.Add(this.tMin);
            this.groupBox.Controls.Add(this.PgStep);
            this.groupBox.Controls.Add(this.PgMax);
            this.groupBox.Controls.Add(this.PgMin);
            this.groupBox.Controls.Add(this.label7);
            this.groupBox.Controls.Add(this.label6);
            this.groupBox.Controls.Add(this.label5);
            this.groupBox.Controls.Add(this.label4);
            this.groupBox.Controls.Add(this.label3);
            this.groupBox.Controls.Add(this.label2);
            this.groupBox.Controls.Add(this.label1);
            this.groupBox.Controls.Add(this.comboBoxMaterial);
            this.groupBox.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox.Location = new System.Drawing.Point(8, 6);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(336, 446);
            this.groupBox.TabIndex = 1;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "Входные данные";
            // 
            // buttonExport
            // 
            this.buttonExport.Image = ((System.Drawing.Image)(resources.GetObject("buttonExport.Image")));
            this.buttonExport.Location = new System.Drawing.Point(273, 378);
            this.buttonExport.Name = "buttonExport";
            this.buttonExport.Size = new System.Drawing.Size(54, 50);
            this.buttonExport.TabIndex = 23;
            this.buttonExport.Text = "                               ";
            this.buttonExport.UseVisualStyleBackColor = true;
            this.buttonExport.Click += new System.EventHandler(this.buttonExport_Click);
            // 
            // buttonClearBox1
            // 
            this.buttonClearBox1.Location = new System.Drawing.Point(138, 378);
            this.buttonClearBox1.Name = "buttonClearBox1";
            this.buttonClearBox1.Size = new System.Drawing.Size(129, 50);
            this.buttonClearBox1.TabIndex = 22;
            this.buttonClearBox1.Text = "Очистить поля";
            this.buttonClearBox1.UseVisualStyleBackColor = true;
            this.buttonClearBox1.Click += new System.EventHandler(this.buttonClearBox1_Click);
            // 
            // buttonСalculate1
            // 
            this.buttonСalculate1.Location = new System.Drawing.Point(3, 378);
            this.buttonСalculate1.Name = "buttonСalculate1";
            this.buttonСalculate1.Size = new System.Drawing.Size(129, 50);
            this.buttonСalculate1.TabIndex = 21;
            this.buttonСalculate1.Text = "Рассчитать ";
            this.buttonСalculate1.UseVisualStyleBackColor = true;
            this.buttonСalculate1.Click += new System.EventHandler(this.buttonСalculate1_Click);
            // 
            // tStep
            // 
            this.tStep.Location = new System.Drawing.Point(156, 318);
            this.tStep.Name = "tStep";
            this.tStep.Size = new System.Drawing.Size(144, 25);
            this.tStep.TabIndex = 20;
            // 
            // tMax
            // 
            this.tMax.Location = new System.Drawing.Point(156, 270);
            this.tMax.Name = "tMax";
            this.tMax.Size = new System.Drawing.Size(144, 25);
            this.tMax.TabIndex = 19;
            // 
            // tMin
            // 
            this.tMin.Location = new System.Drawing.Point(156, 220);
            this.tMin.Name = "tMin";
            this.tMin.Size = new System.Drawing.Size(144, 25);
            this.tMin.TabIndex = 18;
            // 
            // PgStep
            // 
            this.PgStep.Location = new System.Drawing.Point(156, 172);
            this.PgStep.Name = "PgStep";
            this.PgStep.Size = new System.Drawing.Size(144, 25);
            this.PgStep.TabIndex = 17;
            // 
            // PgMax
            // 
            this.PgMax.Location = new System.Drawing.Point(156, 130);
            this.PgMax.Name = "PgMax";
            this.PgMax.Size = new System.Drawing.Size(144, 25);
            this.PgMax.TabIndex = 16;
            // 
            // PgMin
            // 
            this.PgMin.Location = new System.Drawing.Point(156, 84);
            this.PgMin.Name = "PgMin";
            this.PgMin.Size = new System.Drawing.Size(144, 25);
            this.PgMin.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 36);
            this.label7.TabIndex = 14;
            this.label7.Text = "Тип спекаемого \r\nматериала:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 318);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 54);
            this.label6.TabIndex = 13;
            this.label6.Text = "Шаг температуры \r\nспекания, °С\r\n\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 270);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 36);
            this.label5.TabIndex = 12;
            this.label5.Text = "Макс. температура\r\nспекания, °С\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 36);
            this.label4.TabIndex = 11;
            this.label4.Text = "Мин. температура\r\nспекания, °С";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 36);
            this.label3.TabIndex = 10;
            this.label3.Text = "Шаг давления \r\nв печи, атм\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 36);
            this.label2.TabIndex = 9;
            this.label2.Text = "Мин. давление\r\nгаза в печи, атм";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 36);
            this.label1.TabIndex = 8;
            this.label1.Text = "Макс. давление \r\nгаза в печи, атм";
            // 
            // comboBoxMaterial
            // 
            this.comboBoxMaterial.FormattingEnabled = true;
            this.comboBoxMaterial.Location = new System.Drawing.Point(138, 42);
            this.comboBoxMaterial.Name = "comboBoxMaterial";
            this.comboBoxMaterial.Size = new System.Drawing.Size(192, 26);
            this.comboBoxMaterial.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(0, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1372, 871);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.groupBox);
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1364, 842);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Рабочая зона";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 458);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1350, 407);
            this.dataGridView1.TabIndex = 3;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(344, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1008, 446);
            this.tabControl2.TabIndex = 10;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Label_Info);
            this.tabPage2.Controls.Add(this.chartAreaOne);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1000, 417);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "График №1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Label_Info
            // 
            this.Label_Info.AutoSize = true;
            this.Label_Info.BackColor = System.Drawing.Color.White;
            this.Label_Info.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_Info.Location = new System.Drawing.Point(724, 114);
            this.Label_Info.Name = "Label_Info";
            this.Label_Info.Size = new System.Drawing.Size(37, 16);
            this.Label_Info.TabIndex = 9;
            this.Label_Info.Text = "TEXT";
            // 
            // chartAreaOne
            // 
            chartArea1.Name = "ChartArea1";
            this.chartAreaOne.ChartAreas.Add(chartArea1);
            this.chartAreaOne.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chartAreaOne.Legends.Add(legend1);
            this.chartAreaOne.Location = new System.Drawing.Point(3, 3);
            this.chartAreaOne.Name = "chartAreaOne";
            series1.BorderWidth = 5;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.LegendText = "Прочность твердого сплава при минимальной температуре";
            series1.Name = "Series1";
            series1.YValuesPerPoint = 4;
            series2.BorderWidth = 5;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Legend = "Legend1";
            series2.LegendText = "Прочность твердого сплава при средней температуре";
            series2.Name = "Series2";
            series3.BorderWidth = 5;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Legend1";
            series3.LegendText = "Прочность твердого сплава при максимальной температуре";
            series3.Name = "Series3";
            this.chartAreaOne.Series.Add(series1);
            this.chartAreaOne.Series.Add(series2);
            this.chartAreaOne.Series.Add(series3);
            this.chartAreaOne.Size = new System.Drawing.Size(994, 411);
            this.chartAreaOne.TabIndex = 8;
            this.chartAreaOne.Text = "chart1";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.chartAreaTwo);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1000, 417);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "График №2";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // chartAreaTwo
            // 
            chartArea2.Name = "ChartArea1";
            this.chartAreaTwo.ChartAreas.Add(chartArea2);
            this.chartAreaTwo.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chartAreaTwo.Legends.Add(legend2);
            this.chartAreaTwo.Location = new System.Drawing.Point(3, 3);
            this.chartAreaTwo.Name = "chartAreaTwo";
            this.chartAreaTwo.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series4.BorderWidth = 5;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series4.Legend = "Legend1";
            series4.LegendText = "Прочность твердого сплава при минимальном давление";
            series4.Name = "Series1";
            series4.YValuesPerPoint = 4;
            series5.BorderWidth = 5;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series5.Legend = "Legend1";
            series5.LegendText = "Прочность твердого сплава при среднем давление";
            series5.Name = "Series2";
            series6.BorderWidth = 5;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series6.Legend = "Legend1";
            series6.LegendText = "Прочность твердого сплава при максимальном давление";
            series6.Name = "Series3";
            this.chartAreaTwo.Series.Add(series4);
            this.chartAreaTwo.Series.Add(series5);
            this.chartAreaTwo.Series.Add(series6);
            this.chartAreaTwo.Size = new System.Drawing.Size(994, 411);
            this.chartAreaTwo.TabIndex = 9;
            this.chartAreaTwo.Text = "chartAreaTwo";
            // 
            // Interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1384, 931);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStripControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStripControl;
            this.Name = "Interface";
            this.Text = "Комплекс решения";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CloseAppFormToolStripMenuItem_Click);
            this.menuStripControl.ResumeLayout(false);
            this.menuStripControl.PerformLayout();
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartAreaOne)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartAreaTwo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripControl;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменитьПользователяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem functionAdminsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьредактироватьМатериалToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem экспортВMSExelToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBoxMaterial;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tStep;
        private System.Windows.Forms.TextBox tMax;
        private System.Windows.Forms.TextBox tMin;
        private System.Windows.Forms.TextBox PgStep;
        private System.Windows.Forms.TextBox PgMax;
        private System.Windows.Forms.TextBox PgMin;
        private System.Windows.Forms.Button buttonClearBox1;
        private System.Windows.Forms.Button buttonСalculate1;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAreaOne;
        private System.Windows.Forms.ToolStripMenuItem учетныеЗаписиToolStripMenuItem;
        private System.Windows.Forms.Label Label_Info;
        private System.Windows.Forms.ToolStripMenuItem пользовательToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAreaTwo;
    }
}