﻿namespace TechChemAnalytica
{
    partial class MaterialManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialManager));
            this.dataGridMaterial = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tabChangeMatetial = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ClearButton = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.BoxB0 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.BoxB4 = new System.Windows.Forms.TextBox();
            this.BoxB3 = new System.Windows.Forms.TextBox();
            this.BoxB2 = new System.Windows.Forms.TextBox();
            this.BoxB1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.BoxB5 = new System.Windows.Forms.TextBox();
            this.BoxB6 = new System.Windows.Forms.TextBox();
            this.BoxB7 = new System.Windows.Forms.TextBox();
            this.BoxB8 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.BoxNameMaterial = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.BoxPgMin = new System.Windows.Forms.TextBox();
            this.BoxPgMax = new System.Windows.Forms.TextBox();
            this.BoxPgStep = new System.Windows.Forms.TextBox();
            this.BoxtMax = new System.Windows.Forms.TextBox();
            this.BoxtMin = new System.Windows.Forms.TextBox();
            this.BoxtStep = new System.Windows.Forms.TextBox();
            this.InsertDB = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.ClearButton2 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.BBoxB0 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.BBoxB4 = new System.Windows.Forms.TextBox();
            this.BBoxB3 = new System.Windows.Forms.TextBox();
            this.BBoxB2 = new System.Windows.Forms.TextBox();
            this.BBoxB1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.BBoxB5 = new System.Windows.Forms.TextBox();
            this.BBoxB6 = new System.Windows.Forms.TextBox();
            this.BBoxB7 = new System.Windows.Forms.TextBox();
            this.BBoxB8 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.BBoxNameMaterial = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.BBoxPgMin = new System.Windows.Forms.TextBox();
            this.BBoxPgMax = new System.Windows.Forms.TextBox();
            this.BBoxPgStep = new System.Windows.Forms.TextBox();
            this.BBoxtMax = new System.Windows.Forms.TextBox();
            this.BBoxtMin = new System.Windows.Forms.TextBox();
            this.BBoxtStep = new System.Windows.Forms.TextBox();
            this.UpdateButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMaterial)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabChangeMatetial.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridMaterial
            // 
            this.dataGridMaterial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridMaterial.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridMaterial.Location = new System.Drawing.Point(3, 332);
            this.dataGridMaterial.Name = "dataGridMaterial";
            this.dataGridMaterial.Size = new System.Drawing.Size(770, 324);
            this.dataGridMaterial.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.dataGridMaterial, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tabChangeMatetial, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(776, 659);
            this.tableLayoutPanel3.TabIndex = 34;
            // 
            // tabChangeMatetial
            // 
            this.tabChangeMatetial.Controls.Add(this.tabPage1);
            this.tabChangeMatetial.Controls.Add(this.tabPage2);
            this.tabChangeMatetial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabChangeMatetial.Location = new System.Drawing.Point(3, 3);
            this.tabChangeMatetial.Name = "tabChangeMatetial";
            this.tabChangeMatetial.SelectedIndex = 0;
            this.tabChangeMatetial.Size = new System.Drawing.Size(770, 318);
            this.tabChangeMatetial.TabIndex = 33;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ClearButton);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Controls.Add(this.InsertDB);
            this.tabPage1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(762, 289);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавление материала";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ClearButton.Location = new System.Drawing.Point(614, 234);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(125, 47);
            this.ClearButton.TabIndex = 38;
            this.ClearButton.Text = "Очистить поля";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(452, 13);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(305, 22);
            this.label18.TabIndex = 37;
            this.label18.Text = "Коэф. математической модели";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.BoxB0, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.BoxB4, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.BoxB3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.BoxB2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.BoxB1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label13, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label14, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label15, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label16, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.BoxB5, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.BoxB6, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.BoxB7, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.BoxB8, 3, 3);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(456, 71);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(283, 150);
            this.tableLayoutPanel2.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "b0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(3, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "b1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(3, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "b2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(3, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "b3";
            // 
            // BoxB0
            // 
            this.BoxB0.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB0.Location = new System.Drawing.Point(33, 3);
            this.BoxB0.Name = "BoxB0";
            this.BoxB0.Size = new System.Drawing.Size(100, 22);
            this.BoxB0.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(3, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "b4";
            // 
            // BoxB4
            // 
            this.BoxB4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold);
            this.BoxB4.Location = new System.Drawing.Point(33, 123);
            this.BoxB4.Name = "BoxB4";
            this.BoxB4.Size = new System.Drawing.Size(100, 22);
            this.BoxB4.TabIndex = 25;
            // 
            // BoxB3
            // 
            this.BoxB3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB3.Location = new System.Drawing.Point(33, 93);
            this.BoxB3.Name = "BoxB3";
            this.BoxB3.Size = new System.Drawing.Size(100, 22);
            this.BoxB3.TabIndex = 24;
            // 
            // BoxB2
            // 
            this.BoxB2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB2.Location = new System.Drawing.Point(33, 63);
            this.BoxB2.Name = "BoxB2";
            this.BoxB2.Size = new System.Drawing.Size(100, 22);
            this.BoxB2.TabIndex = 23;
            // 
            // BoxB1
            // 
            this.BoxB1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB1.Location = new System.Drawing.Point(33, 33);
            this.BoxB1.Name = "BoxB1";
            this.BoxB1.Size = new System.Drawing.Size(100, 22);
            this.BoxB1.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(139, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 20);
            this.label13.TabIndex = 12;
            this.label13.Text = "b5";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(139, 30);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 20);
            this.label14.TabIndex = 13;
            this.label14.Text = "b6";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(139, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(24, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "b7";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(139, 90);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 20);
            this.label16.TabIndex = 29;
            this.label16.Text = "b8";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BoxB5
            // 
            this.BoxB5.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB5.Location = new System.Drawing.Point(169, 3);
            this.BoxB5.Name = "BoxB5";
            this.BoxB5.Size = new System.Drawing.Size(100, 22);
            this.BoxB5.TabIndex = 26;
            // 
            // BoxB6
            // 
            this.BoxB6.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB6.Location = new System.Drawing.Point(169, 33);
            this.BoxB6.Name = "BoxB6";
            this.BoxB6.Size = new System.Drawing.Size(100, 22);
            this.BoxB6.TabIndex = 27;
            // 
            // BoxB7
            // 
            this.BoxB7.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB7.Location = new System.Drawing.Point(169, 63);
            this.BoxB7.Name = "BoxB7";
            this.BoxB7.Size = new System.Drawing.Size(100, 22);
            this.BoxB7.TabIndex = 28;
            // 
            // BoxB8
            // 
            this.BoxB8.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxB8.Location = new System.Drawing.Point(169, 93);
            this.BoxB8.Name = "BoxB8";
            this.BoxB8.Size = new System.Drawing.Size(100, 22);
            this.BoxB8.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(6, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(392, 22);
            this.label17.TabIndex = 35;
            this.label17.Text = "Характеристики объекта исследования";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.41237F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.58763F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.BoxNameMaterial, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.BoxPgMin, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BoxPgMax, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BoxPgStep, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.BoxtMax, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.BoxtMin, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.BoxtStep, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(10, 68);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(388, 213);
            this.tableLayoutPanel1.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Тип спекаемого материала:\r\n";
            // 
            // BoxNameMaterial
            // 
            this.BoxNameMaterial.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxNameMaterial.Location = new System.Drawing.Point(218, 3);
            this.BoxNameMaterial.Name = "BoxNameMaterial";
            this.BoxNameMaterial.Size = new System.Drawing.Size(157, 22);
            this.BoxNameMaterial.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(3, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Мин. давление газа в печи, атм\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(3, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Макс. давление газа в печи, атм\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(3, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 30);
            this.label4.TabIndex = 3;
            this.label4.Text = "Шаг давления в печи, атм\r\n\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(3, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(205, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Макс. температура спекания, °С";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(3, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(200, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Мин. температура спекания, °С\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(3, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(199, 33);
            this.label7.TabIndex = 6;
            this.label7.Text = "Шаг температуры спекания, °С\r\n\r\n\r\n";
            // 
            // BoxPgMin
            // 
            this.BoxPgMin.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxPgMin.Location = new System.Drawing.Point(218, 33);
            this.BoxPgMin.Name = "BoxPgMin";
            this.BoxPgMin.Size = new System.Drawing.Size(100, 22);
            this.BoxPgMin.TabIndex = 16;
            // 
            // BoxPgMax
            // 
            this.BoxPgMax.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxPgMax.Location = new System.Drawing.Point(218, 63);
            this.BoxPgMax.Name = "BoxPgMax";
            this.BoxPgMax.Size = new System.Drawing.Size(100, 22);
            this.BoxPgMax.TabIndex = 17;
            // 
            // BoxPgStep
            // 
            this.BoxPgStep.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxPgStep.Location = new System.Drawing.Point(218, 93);
            this.BoxPgStep.Name = "BoxPgStep";
            this.BoxPgStep.Size = new System.Drawing.Size(100, 22);
            this.BoxPgStep.TabIndex = 18;
            // 
            // BoxtMax
            // 
            this.BoxtMax.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxtMax.Location = new System.Drawing.Point(218, 153);
            this.BoxtMax.Name = "BoxtMax";
            this.BoxtMax.Size = new System.Drawing.Size(100, 22);
            this.BoxtMax.TabIndex = 20;
            // 
            // BoxtMin
            // 
            this.BoxtMin.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxtMin.Location = new System.Drawing.Point(218, 123);
            this.BoxtMin.Name = "BoxtMin";
            this.BoxtMin.Size = new System.Drawing.Size(100, 22);
            this.BoxtMin.TabIndex = 19;
            // 
            // BoxtStep
            // 
            this.BoxtStep.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoxtStep.Location = new System.Drawing.Point(218, 183);
            this.BoxtStep.Name = "BoxtStep";
            this.BoxtStep.Size = new System.Drawing.Size(100, 22);
            this.BoxtStep.TabIndex = 21;
            // 
            // InsertDB
            // 
            this.InsertDB.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InsertDB.Location = new System.Drawing.Point(456, 232);
            this.InsertDB.Name = "InsertDB";
            this.InsertDB.Size = new System.Drawing.Size(133, 47);
            this.InsertDB.TabIndex = 32;
            this.InsertDB.Text = "Записать значения";
            this.InsertDB.UseVisualStyleBackColor = true;
            this.InsertDB.Click += new System.EventHandler(this.InsertDB_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DeleteButton);
            this.tabPage2.Controls.Add(this.ClearButton2);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.tableLayoutPanel4);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.tableLayoutPanel5);
            this.tabPage2.Controls.Add(this.UpdateButton);
            this.tabPage2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(762, 289);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Изменение материала";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DeleteButton.Location = new System.Drawing.Point(434, 252);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(185, 26);
            this.DeleteButton.TabIndex = 45;
            this.DeleteButton.Text = "Удалить материал";
            this.DeleteButton.UseVisualStyleBackColor = true;
            // 
            // ClearButton2
            // 
            this.ClearButton2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ClearButton2.Location = new System.Drawing.Point(625, 224);
            this.ClearButton2.Name = "ClearButton2";
            this.ClearButton2.Size = new System.Drawing.Size(125, 54);
            this.ClearButton2.TabIndex = 44;
            this.ClearButton2.Text = "Очистить поля";
            this.ClearButton2.UseVisualStyleBackColor = true;
            this.ClearButton2.Click += new System.EventHandler(this.ClearButton2_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(452, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(305, 22);
            this.label19.TabIndex = 43;
            this.label19.Text = "Коэф. математической модели";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label21, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label22, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label23, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB0, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label24, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB4, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB3, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB2, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB1, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label25, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label26, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label27, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.label28, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB5, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB6, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB7, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.BBoxB8, 3, 3);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(456, 71);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 5;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(283, 150);
            this.tableLayoutPanel4.TabIndex = 42;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(3, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(24, 20);
            this.label20.TabIndex = 7;
            this.label20.Text = "b0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(3, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(24, 20);
            this.label21.TabIndex = 8;
            this.label21.Text = "b1";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(3, 60);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(24, 20);
            this.label22.TabIndex = 9;
            this.label22.Text = "b2";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(3, 90);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(24, 20);
            this.label23.TabIndex = 10;
            this.label23.Text = "b3";
            // 
            // BBoxB0
            // 
            this.BBoxB0.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB0.Location = new System.Drawing.Point(33, 3);
            this.BBoxB0.Name = "BBoxB0";
            this.BBoxB0.Size = new System.Drawing.Size(100, 22);
            this.BBoxB0.TabIndex = 31;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(3, 120);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(24, 20);
            this.label24.TabIndex = 11;
            this.label24.Text = "b4";
            // 
            // BBoxB4
            // 
            this.BBoxB4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold);
            this.BBoxB4.Location = new System.Drawing.Point(33, 123);
            this.BBoxB4.Name = "BBoxB4";
            this.BBoxB4.Size = new System.Drawing.Size(100, 22);
            this.BBoxB4.TabIndex = 25;
            // 
            // BBoxB3
            // 
            this.BBoxB3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB3.Location = new System.Drawing.Point(33, 93);
            this.BBoxB3.Name = "BBoxB3";
            this.BBoxB3.Size = new System.Drawing.Size(100, 22);
            this.BBoxB3.TabIndex = 24;
            // 
            // BBoxB2
            // 
            this.BBoxB2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB2.Location = new System.Drawing.Point(33, 63);
            this.BBoxB2.Name = "BBoxB2";
            this.BBoxB2.Size = new System.Drawing.Size(100, 22);
            this.BBoxB2.TabIndex = 23;
            // 
            // BBoxB1
            // 
            this.BBoxB1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB1.Location = new System.Drawing.Point(33, 33);
            this.BBoxB1.Name = "BBoxB1";
            this.BBoxB1.Size = new System.Drawing.Size(100, 22);
            this.BBoxB1.TabIndex = 22;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(139, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(24, 20);
            this.label25.TabIndex = 12;
            this.label25.Text = "b5";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(139, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 20);
            this.label26.TabIndex = 13;
            this.label26.Text = "b6";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(139, 60);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(24, 20);
            this.label27.TabIndex = 14;
            this.label27.Text = "b7";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(139, 90);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(24, 20);
            this.label28.TabIndex = 29;
            this.label28.Text = "b8";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BBoxB5
            // 
            this.BBoxB5.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB5.Location = new System.Drawing.Point(169, 3);
            this.BBoxB5.Name = "BBoxB5";
            this.BBoxB5.Size = new System.Drawing.Size(100, 22);
            this.BBoxB5.TabIndex = 26;
            // 
            // BBoxB6
            // 
            this.BBoxB6.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB6.Location = new System.Drawing.Point(169, 33);
            this.BBoxB6.Name = "BBoxB6";
            this.BBoxB6.Size = new System.Drawing.Size(100, 22);
            this.BBoxB6.TabIndex = 27;
            // 
            // BBoxB7
            // 
            this.BBoxB7.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB7.Location = new System.Drawing.Point(169, 63);
            this.BBoxB7.Name = "BBoxB7";
            this.BBoxB7.Size = new System.Drawing.Size(100, 22);
            this.BBoxB7.TabIndex = 28;
            // 
            // BBoxB8
            // 
            this.BBoxB8.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxB8.Location = new System.Drawing.Point(169, 93);
            this.BBoxB8.Name = "BBoxB8";
            this.BBoxB8.Size = new System.Drawing.Size(100, 22);
            this.BBoxB8.TabIndex = 30;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(6, 13);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(392, 22);
            this.label29.TabIndex = 41;
            this.label29.Text = "Характеристики объекта исследования";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.41237F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.58763F));
            this.tableLayoutPanel5.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.BBoxNameMaterial, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label31, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label32, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label33, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.label34, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.label35, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.label36, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.BBoxPgMin, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.BBoxPgMax, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.BBoxPgStep, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.BBoxtMax, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.BBoxtMin, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.BBoxtStep, 1, 6);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(10, 68);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 7;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(388, 213);
            this.tableLayoutPanel5.TabIndex = 40;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(180, 20);
            this.label30.TabIndex = 1;
            this.label30.Text = "Тип спекаемого материала:\r\n";
            // 
            // BBoxNameMaterial
            // 
            this.BBoxNameMaterial.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxNameMaterial.Location = new System.Drawing.Point(218, 3);
            this.BBoxNameMaterial.Name = "BBoxNameMaterial";
            this.BBoxNameMaterial.Size = new System.Drawing.Size(157, 22);
            this.BBoxNameMaterial.TabIndex = 15;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(3, 30);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(200, 20);
            this.label31.TabIndex = 2;
            this.label31.Text = "Мин. давление газа в печи, атм\r\n";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(3, 60);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(205, 20);
            this.label32.TabIndex = 2;
            this.label32.Text = "Макс. давление газа в печи, атм\r\n";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(3, 90);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(167, 30);
            this.label33.TabIndex = 3;
            this.label33.Text = "Шаг давления в печи, атм\r\n\r\n";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(3, 150);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(205, 20);
            this.label34.TabIndex = 5;
            this.label34.Text = "Макс. температура спекания, °С";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(3, 120);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(200, 20);
            this.label35.TabIndex = 4;
            this.label35.Text = "Мин. температура спекания, °С\r\n";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label36.Location = new System.Drawing.Point(3, 180);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(199, 33);
            this.label36.TabIndex = 6;
            this.label36.Text = "Шаг температуры спекания, °С\r\n\r\n\r\n";
            // 
            // BBoxPgMin
            // 
            this.BBoxPgMin.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxPgMin.Location = new System.Drawing.Point(218, 33);
            this.BBoxPgMin.Name = "BBoxPgMin";
            this.BBoxPgMin.Size = new System.Drawing.Size(100, 22);
            this.BBoxPgMin.TabIndex = 16;
            // 
            // BBoxPgMax
            // 
            this.BBoxPgMax.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxPgMax.Location = new System.Drawing.Point(218, 63);
            this.BBoxPgMax.Name = "BBoxPgMax";
            this.BBoxPgMax.Size = new System.Drawing.Size(100, 22);
            this.BBoxPgMax.TabIndex = 17;
            // 
            // BBoxPgStep
            // 
            this.BBoxPgStep.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxPgStep.Location = new System.Drawing.Point(218, 93);
            this.BBoxPgStep.Name = "BBoxPgStep";
            this.BBoxPgStep.Size = new System.Drawing.Size(100, 22);
            this.BBoxPgStep.TabIndex = 18;
            // 
            // BBoxtMax
            // 
            this.BBoxtMax.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxtMax.Location = new System.Drawing.Point(218, 153);
            this.BBoxtMax.Name = "BBoxtMax";
            this.BBoxtMax.Size = new System.Drawing.Size(100, 22);
            this.BBoxtMax.TabIndex = 20;
            // 
            // BBoxtMin
            // 
            this.BBoxtMin.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxtMin.Location = new System.Drawing.Point(218, 123);
            this.BBoxtMin.Name = "BBoxtMin";
            this.BBoxtMin.Size = new System.Drawing.Size(100, 22);
            this.BBoxtMin.TabIndex = 19;
            // 
            // BBoxtStep
            // 
            this.BBoxtStep.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BBoxtStep.Location = new System.Drawing.Point(218, 183);
            this.BBoxtStep.Name = "BBoxtStep";
            this.BBoxtStep.Size = new System.Drawing.Size(100, 22);
            this.BBoxtStep.TabIndex = 21;
            // 
            // UpdateButton
            // 
            this.UpdateButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UpdateButton.Location = new System.Drawing.Point(434, 224);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(185, 26);
            this.UpdateButton.TabIndex = 39;
            this.UpdateButton.Text = "Изменить значение";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // MaterialManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(780, 668);
            this.Controls.Add(this.tableLayoutPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MaterialManager";
            this.Text = "Добавить/редактировать материал";
            this.Load += new System.EventHandler(this.MaterialManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMaterial)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tabChangeMatetial.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridMaterial;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TabControl tabChangeMatetial;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox BoxB0;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox BoxB4;
        private System.Windows.Forms.TextBox BoxB3;
        private System.Windows.Forms.TextBox BoxB2;
        private System.Windows.Forms.TextBox BoxB1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox BoxB5;
        private System.Windows.Forms.TextBox BoxB6;
        private System.Windows.Forms.TextBox BoxB7;
        private System.Windows.Forms.TextBox BoxB8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BoxNameMaterial;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox BoxPgMin;
        private System.Windows.Forms.TextBox BoxPgMax;
        private System.Windows.Forms.TextBox BoxPgStep;
        private System.Windows.Forms.TextBox BoxtMax;
        private System.Windows.Forms.TextBox BoxtMin;
        private System.Windows.Forms.TextBox BoxtStep;
        private System.Windows.Forms.Button InsertDB;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button ClearButton2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox BBoxB0;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox BBoxB4;
        private System.Windows.Forms.TextBox BBoxB3;
        private System.Windows.Forms.TextBox BBoxB2;
        private System.Windows.Forms.TextBox BBoxB1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox BBoxB5;
        private System.Windows.Forms.TextBox BBoxB6;
        private System.Windows.Forms.TextBox BBoxB7;
        private System.Windows.Forms.TextBox BBoxB8;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox BBoxNameMaterial;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox BBoxPgMin;
        private System.Windows.Forms.TextBox BBoxPgMax;
        private System.Windows.Forms.TextBox BBoxPgStep;
        private System.Windows.Forms.TextBox BBoxtMax;
        private System.Windows.Forms.TextBox BBoxtMin;
        private System.Windows.Forms.TextBox BBoxtStep;
        private System.Windows.Forms.Button UpdateButton;
    }
}